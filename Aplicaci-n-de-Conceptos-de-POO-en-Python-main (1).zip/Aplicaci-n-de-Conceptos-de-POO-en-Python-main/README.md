# Aplicaci-n-de-Conceptos-de-POO-en-Python
Objeto, Herencia, Encapsulación y Polimorfismo
